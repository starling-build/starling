// Copyright 2014 The Flutter Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/// Sliver list type for variable-sized children.
///
/// **Dart Source:** `packages/flutter/lib/src/rendering/sliver_list.dart`

import FlutterSwiftBridge

// =============================================================================
// MARK: - RenderSliverList
// =============================================================================

/// A sliver that places multiple box children in a linear array along the main
/// axis.
///
/// Each child is forced to have the `SliverConstraints.crossAxisExtent` in the
/// cross axis but determines its own main axis extent.
///
/// `RenderSliverList` determines its scroll offset by "dead reckoning" because
/// children outside the visible part of the sliver are not materialized, which
/// means `RenderSliverList` cannot learn their main axis extent. Instead, newly
/// materialized children are placed adjacent to existing children. If this dead
/// reckoning results in a logical inconsistency (e.g., attempting to place the
/// zeroth child at a scroll offset other than zero), the `RenderSliverList`
/// generates a `SliverGeometry.scrollOffsetCorrection` to restore consistency.
///
/// If the children have a fixed extent in the main axis, consider using
/// `RenderSliverFixedExtentList` rather than `RenderSliverList` because
/// `RenderSliverFixedExtentList` does not need to perform layout on its
/// children to obtain their extent in the main axis and is therefore more
/// efficient.
///
/// See also:
///
///  - `RenderSliverFixedExtentList`, which is more efficient for children with
///    the same extent in the main axis.
///
/// **Dart Source:** `sliver_list.dart:40-346`
open class RenderSliverList: RenderSliverMultiBoxAdaptor {

    // MARK: - Initializer

    /// Creates a sliver that places multiple box children in a linear array along
    /// the main axis.
    ///
    /// **Dart Source:** `sliver_list.dart:43`
    public override init(childManager: any RenderSliverBoxChildManager) {
        super.init(childManager: childManager)
    }

    // MARK: - Layout

    /// Performs layout by walking from the first visible child outward in both
    /// directions, creating children as needed.
    ///
    /// The algorithm starts from the first child (or creates one if none exist),
    /// walks backward to ensure children before the scroll offset are present,
    /// then walks forward to fill the viewport. Children outside the visible
    /// range are garbage-collected.
    ///
    /// If a logical inconsistency is detected (e.g. child 0 placed at a nonzero
    /// offset), a `scrollOffsetCorrection` is emitted to restore consistency.
    ///
    /// **Dart Source:** `sliver_list.dart:46-345`
    open override func performLayout() {
        let constraints = self.sliverConstraints
        childManager.didStartLayout()
        childManager.setDidUnderflow(false)

        let scrollOffset = constraints.scrollOffset + constraints.cacheOrigin
        assert(scrollOffset >= 0.0)
        let remainingExtent = constraints.remainingCacheExtent
        assert(remainingExtent >= 0.0)
        let targetEndScrollOffset = scrollOffset + remainingExtent
        let childConstraints = constraints.asBoxConstraints()
        var leadingGarbage = 0
        var trailingGarbage = 0
        var reachedEnd = false

        // This algorithm in principle is straight-forward: find the first child
        // that overlaps the given scrollOffset, creating more children at the top
        // of the list if necessary, then walk down the list updating and laying out
        // each child and adding more at the end if necessary until we have enough
        // children to cover the entire viewport.
        //
        // It is complicated by one minor issue, which is that any time you update
        // or create a child, it's possible that some of the children that
        // haven't yet been laid out will be removed, leaving the list in an
        // inconsistent state, and requiring that missing nodes be recreated.
        //
        // To keep this mess tractable, this algorithm starts from what is currently
        // the first child, if any, and then walks up and/or down from there, so
        // that the nodes that might get removed are always at the edges of what has
        // already been laid out.

        // Make sure we have at least one child to start from.
        if firstChild == nil {
            if !addInitialChild() {
                // There are no children.
                geometry = .zero
                childManager.didFinishLayout()
                return
            }
        }

        // We have at least one child.

        // These variables track the range of children that we have laid out. Within
        // this range, the children have consecutive indices. Outside this range,
        // it's possible for a child to get removed without notice.
        var leadingChildWithLayout: RenderBox?
        var trailingChildWithLayout: RenderBox?

        var earliestUsefulChild: RenderBox? = firstChild

        // A firstChild with null layout offset is likely a result of children
        // reordering.
        //
        // We rely on firstChild to have accurate layout offset. In the case of null
        // layout offset, we have to find the first child that has valid layout
        // offset.
        if childScrollOffset(firstChild!) == nil {
            var leadingChildrenWithoutLayoutOffset = 0
            while earliestUsefulChild != nil && childScrollOffset(earliestUsefulChild!) == nil {
                earliestUsefulChild = childAfter(earliestUsefulChild!)
                leadingChildrenWithoutLayoutOffset += 1
            }
            // We should be able to destroy children with null layout offset safely,
            // because they are likely outside of viewport
            collectGarbage(leadingChildrenWithoutLayoutOffset, 0)
            // If can not find a valid layout offset, start from the initial child.
            if firstChild == nil {
                if !addInitialChild() {
                    // There are no children.
                    geometry = .zero
                    childManager.didFinishLayout()
                    return
                }
            }
        }

        // Find the last child that is at or before the scrollOffset.
        earliestUsefulChild = firstChild
        var earliestScrollOffset = childScrollOffset(earliestUsefulChild!)!
        while earliestScrollOffset > scrollOffset {
            // We have to add children before the earliestUsefulChild.
            earliestUsefulChild = insertAndLayoutLeadingChild(
                childConstraints,
                parentUsesSize: true
            )
            if earliestUsefulChild == nil {
                let childParentData =
                    firstChild!.parentData! as! SliverMultiBoxAdaptorParentData
                childParentData.layoutOffset = 0.0

                if scrollOffset == 0.0 {
                    // insertAndLayoutLeadingChild only lays out the children before
                    // firstChild. In this case, nothing has been laid out. We have
                    // to lay out firstChild manually.
                    firstChild!.layout(childConstraints, parentUsesSize: true)
                    earliestUsefulChild = firstChild
                    leadingChildWithLayout = earliestUsefulChild
                    if trailingChildWithLayout == nil {
                        trailingChildWithLayout = earliestUsefulChild
                    }
                    break
                } else {
                    // We ran out of children before reaching the scroll offset.
                    // We must inform our parent that this sliver cannot fulfill
                    // its contract and that we need a scroll offset correction.
                    geometry = SliverGeometry(scrollOffsetCorrection: -scrollOffset)
                    return
                }
            }

            let firstChildScrollOffset = earliestScrollOffset - paintExtentOf(firstChild!)
            // firstChildScrollOffset may contain double precision error
            if firstChildScrollOffset < -precisionErrorTolerance {
                // Let's assume there is no child before the first child. We will
                // correct it on the next layout if it is not.
                geometry = SliverGeometry(scrollOffsetCorrection: -firstChildScrollOffset)
                let childParentData =
                    firstChild!.parentData! as! SliverMultiBoxAdaptorParentData
                childParentData.layoutOffset = 0.0
                return
            }

            let childParentData =
                earliestUsefulChild!.parentData! as! SliverMultiBoxAdaptorParentData
            childParentData.layoutOffset = firstChildScrollOffset
            assert(earliestUsefulChild === firstChild)
            leadingChildWithLayout = earliestUsefulChild
            if trailingChildWithLayout == nil {
                trailingChildWithLayout = earliestUsefulChild
            }
            earliestScrollOffset = childScrollOffset(earliestUsefulChild!)!
        }

        assert(childScrollOffset(firstChild!)! > -precisionErrorTolerance)

        // If the scroll offset is at zero, we should make sure we are
        // actually at the beginning of the list.
        if scrollOffset < precisionErrorTolerance {
            // We iterate from the firstChild in case the leading child has a 0 paint
            // extent.
            while indexOf(firstChild!) > 0 {
                let earliestScrollOffsetLocal = childScrollOffset(firstChild!)!
                // We correct one child at a time. If there are more children before
                // the earliestUsefulChild, we will correct it once the scroll offset
                // reaches zero again.
                earliestUsefulChild = insertAndLayoutLeadingChild(
                    childConstraints,
                    parentUsesSize: true
                )
                assert(earliestUsefulChild != nil)
                let firstChildScrollOffset = earliestScrollOffsetLocal - paintExtentOf(firstChild!)
                let childParentData =
                    firstChild!.parentData! as! SliverMultiBoxAdaptorParentData
                childParentData.layoutOffset = 0.0
                // We only need to correct if the leading child actually has a
                // paint extent.
                if firstChildScrollOffset < -precisionErrorTolerance {
                    geometry = SliverGeometry(
                        scrollOffsetCorrection: -firstChildScrollOffset
                    )
                    return
                }
            }
        }

        // At this point, earliestUsefulChild is the first child, and is a child
        // whose scrollOffset is at or before the scrollOffset, and
        // leadingChildWithLayout and trailingChildWithLayout are either null or
        // cover a range of render boxes that we have laid out with the first being
        // the same as earliestUsefulChild and the last being either at or after the
        // scroll offset.

        assert(earliestUsefulChild === firstChild)
        assert(childScrollOffset(earliestUsefulChild!)! <= scrollOffset)

        // Make sure we've laid out at least one child.
        if leadingChildWithLayout == nil {
            earliestUsefulChild!.layout(childConstraints, parentUsesSize: true)
            leadingChildWithLayout = earliestUsefulChild
            trailingChildWithLayout = earliestUsefulChild
        }

        // Here, earliestUsefulChild is still the first child, it's got a
        // scrollOffset that is at or before our actual scrollOffset, and it has
        // been laid out, and is in fact our leadingChildWithLayout. It's possible
        // that some children beyond that one have also been laid out.

        var inLayoutRange = true
        var child: RenderBox? = earliestUsefulChild
        var index = indexOf(child!)
        var endScrollOffset = childScrollOffset(child!)! + paintExtentOf(child!)

        /// Advances to the next child, laying it out if necessary.
        /// Returns true if we advanced, false if we have no more children.
        func advance() -> Bool {
            assert(child != nil)
            if child === trailingChildWithLayout {
                inLayoutRange = false
            }
            child = childAfter(child!)
            if child == nil {
                inLayoutRange = false
            }
            index += 1
            if !inLayoutRange {
                if child == nil || indexOf(child!) != index {
                    // We are missing a child. Insert it (and lay it out) if possible.
                    child = insertAndLayoutChild(
                        childConstraints,
                        after: trailingChildWithLayout!,
                        parentUsesSize: true
                    )
                    if child == nil {
                        // We have run out of children.
                        return false
                    }
                } else {
                    // Lay out the child.
                    child!.layout(childConstraints, parentUsesSize: true)
                }
                trailingChildWithLayout = child
            }
            assert(child != nil)
            let childParentData =
                child!.parentData! as! SliverMultiBoxAdaptorParentData
            childParentData.layoutOffset = endScrollOffset
            assert(childParentData.index == index)
            endScrollOffset = childScrollOffset(child!)! + paintExtentOf(child!)
            return true
        }

        // Find the first child that ends after the scroll offset.
        while endScrollOffset < scrollOffset {
            leadingGarbage += 1
            if !advance() {
                assert(leadingGarbage == childCount)
                assert(child == nil)
                // we want to make sure we keep the last child around so we know the end scroll offset
                collectGarbage(leadingGarbage - 1, 0)
                assert(firstChild === lastChild)
                let extent = childScrollOffset(lastChild!)! + paintExtentOf(lastChild!)
                geometry = SliverGeometry(
                    scrollExtent: extent,
                    maxPaintExtent: extent
                )
                return
            }
        }

        // Now find the first child that ends after our end.
        while endScrollOffset < targetEndScrollOffset {
            if !advance() {
                reachedEnd = true
                break
            }
        }

        // Finally count up all the remaining children and label them as garbage.
        if child != nil {
            child = childAfter(child!)
            while child != nil {
                trailingGarbage += 1
                child = childAfter(child!)
            }
        }

        // At this point everything should be good to go, we just have to clean up
        // the garbage and report the geometry.

        collectGarbage(leadingGarbage, trailingGarbage)

        assert(debugAssertChildListIsNonEmptyAndContiguous())
        let estimatedMaxScrollOffset: Double
        if reachedEnd {
            estimatedMaxScrollOffset = endScrollOffset
        } else {
            estimatedMaxScrollOffset = childManager.estimateMaxScrollOffset(
                constraints,
                firstIndex: indexOf(firstChild!),
                lastIndex: indexOf(lastChild!),
                leadingScrollOffset: childScrollOffset(firstChild!),
                trailingScrollOffset: endScrollOffset
            )
            assert(
                estimatedMaxScrollOffset
                    >= endScrollOffset - childScrollOffset(firstChild!)!
            )
        }
        let paintExtent = calculatePaintOffset(
            constraints,
            from: childScrollOffset(firstChild!)!,
            to: endScrollOffset
        )
        let cacheExtent = calculateCacheOffset(
            constraints,
            from: childScrollOffset(firstChild!)!,
            to: endScrollOffset
        )
        let targetEndScrollOffsetForPaint =
            constraints.scrollOffset + constraints.remainingPaintExtent
        geometry = SliverGeometry(
            scrollExtent: estimatedMaxScrollOffset,
            paintExtent: paintExtent,
            maxPaintExtent: estimatedMaxScrollOffset,
            // Conservative to avoid flickering away the clip during scroll.
            hasVisualOverflow: endScrollOffset > targetEndScrollOffsetForPaint
                || constraints.scrollOffset > 0.0,
            cacheExtent: cacheExtent
        )

        // We may have started the layout while scrolled to the end, which would not
        // expose a new child.
        if estimatedMaxScrollOffset == endScrollOffset {
            childManager.setDidUnderflow(true)
        }
        childManager.didFinishLayout()
    }
}
