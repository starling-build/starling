# Starling SDK — macos/arm64 bundle (release engine)

The Flutter framework ported to Swift, with the engine binaries it links against.
No engine checkout or toolchain configuration needed.

## Use it

```swift
dependencies: [.package(path: "/opt/starling-sdk-macos-arm64")],
targets: [
    .executableTarget(
        name: "App",
        dependencies: [
            .product(name: "Flutter", package: "starling-sdk-macos-arm64"),
            // The dart:ui types — Offset, Size, Rect, Paint, Canvas. Separate
            // from Flutter, which does not re-export them.
            .product(name: "FlutterSwiftBridge", package: "starling-sdk-macos-arm64"),
            // The windowed host for this platform: it opens the window and
            // starts the engine in Swift mode.
            .product(name: "FlutterCocoa", package: "starling-sdk-macos-arm64"),
        ],
        swiftSettings: [
            // Required. The framework is C++-interop; this is not inherited from
            // the dependency, and without it you get:
            //   module 'FlutterSwiftBridgeCxx' requires feature 'cplusplus'
            .interoperabilityMode(.Cxx),
        ]
    ),
]
```

```swift
import Flutter
import FlutterSwiftBridge

print(Offset(3, 4).distance)   // 5.0
```

**You do not add the engine library to your package, and you do not set a library
path.** This package's own linker settings put `-L` on the link line and bake an
rpath into your executable, so `swift build` and `swift run` find
`libflutter_engine` with no configuration.

It is a path dependency rather than `.package(url:from:)` because locating the
bundled engine needs linker flags SwiftPM classes as unsafe, which it permits for
path dependencies only. Consequence: **moving this directory after building means
rebuilding**, as the engine location is in your binary's rpath.

## Ship your app

The rpath above points here, which is fine on your machine and useless on someone
else's. SwiftPM also puts `@executable_path` in the rpath, so deployment is a copy:

```bash
cp .build/release/App                        dist/
cp -R /opt/starling-sdk-macos-arm64/engine/lib/FlutterMacOS.framework  dist/   # beside the binary
cp    /opt/starling-sdk-macos-arm64/engine/lib/libswift_bridge.dylib   dist/
cp -r /opt/starling-sdk-macos-arm64/engine/share                       dist/   # flutter_assets
```

Both engine binaries carry an `@rpath` install name, so `dist/App` then runs
anywhere with nothing set in the environment. Skip the copy and you get
`Library not loaded: @rpath/libswift_bridge.dylib` at launch, not at build time.
Point your embedder at the framework's
`Versions/A/Resources/icudtl.dat` and at `share/flutter_assets`.

This bundle is built for **macos/arm64**; other targets need their own.

## Layout

    Package.swift Sources/ Tests/   the framework
    Examples/                       the demo and example apps
    engine/lib/                     FlutterMacOS.framework, libswift_bridge.dylib
    engine/lib/FlutterMacOS.framework/Versions/A/Resources/icudtl.dat
                                    ICU data, needed to start an engine —
                                    inside the framework on this platform
    engine/share/flutter_assets/    default asset bundle

## Overrides

`FLUTTER_SWIFT_ENGINE_OUT` points at a different engine build.

