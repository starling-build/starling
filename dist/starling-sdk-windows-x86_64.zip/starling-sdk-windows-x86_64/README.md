# Starling SDK - windows/x86_64 bundle (release engine)

The Flutter framework ported to Swift, with the engine binaries it links
against. No engine checkout or toolchain configuration needed.

## Use it

```swift
dependencies: [.package(path: "C:/starling-sdk-windows-x86_64")],
targets: [
    .executableTarget(
        name: "App",
        dependencies: [
            .product(name: "Flutter", package: "starling-sdk-windows-x86_64"),
            // The dart:ui types - Offset, Size, Rect, Paint, Canvas. Separate
            // from Flutter, which does not re-export them.
            .product(name: "FlutterSwiftBridge", package: "starling-sdk-windows-x86_64"),
            // The desktop host: the engine's own Win32 embedder, Swift-driven.
            // The counterpart of FlutterGTK on Linux.
            .product(name: "FlutterWin32", package: "starling-sdk-windows-x86_64"),
        ],
        swiftSettings: [
            // Required. The framework is C++-interop; this is not inherited
            // from the dependency, and without it you get:
            //   module 'FlutterSwiftBridgeCxx' requires feature 'cplusplus'
            .interoperabilityMode(.Cxx),
        ]
    ),
]
```

Note there are **no `.unsafeFlags` here**. The `-Xcc` math flags in the Linux
bundle's README work around an Ubuntu 26.04 glibc/libstdc++ clash and must not
be copied to Windows.

## Build it

```
tools\build-windows.ps1 -PackagePath C:\path\to\your\package -Configuration release
```

**Use that script rather than plain `swift build` for the first build.** A cold
Clang module cache makes the first C++-interop compilation fail inside MSVC's
own `<xmemory>` with `no matching function for call to 'construct_at'`. That is
a toolchain bug (Swift 6.2.3 / MSVC 14.44), not something your package did: the
failing run still writes a usable module, so the same command run again gets
further, and it needs one pass per interop configuration. The script loops only
while that exact signature appears, so a real build error still fails
immediately. Once the cache is warm, plain `swift build` is fine.

## Run it

Windows has no rpath: the loader finds a DLL beside the `.exe` or on `PATH`.
So a run needs the engine DLLs next to your binary, plus the engine data:

```
copy C:\starling-sdk-windows-x86_64\engine\lib\*.dll           .build\release\
mkdir .build\release\data
copy C:\starling-sdk-windows-x86_64\engine\share\icudtl.dat    .build\release\data\
xcopy /E /I C:\starling-sdk-windows-x86_64\engine\share\flutter_assets .build\release\data\flutter_assets
```

Skip the DLL copy and the app dies at startup with `0xC0000135`
(`STATUS_DLL_NOT_FOUND`) before `main()`; skip the data and the window comes up
black, which looks like a render bug but is a missing file.

## Ship your app

Same copy as above, plus **the Swift runtime DLLs**, which this bundle does not
carry - they belong to your toolchain, exactly as `libswiftCore` does on Linux:

```
copy "%LOCALAPPDATA%\Programs\Swift\Runtimes\<version>\usr\bin\*.dll" dist\
```

A machine without the Swift toolchain gets `0xC0000135` before `main()` without
them, which reads as "the app is broken" rather than "a DLL is missing".

This bundle is built for **windows/x86_64**; other targets need their own.

## Layout

    Package.swift Sources/ Tests/   the framework
    Examples/                       the demo and example apps
    engine/lib/                     flutter_engine.dll + flutter_windows.dll,
                                    each with its .lib import library
    engine/share/icudtl.dat         ICU data, needed to start an engine
    engine/share/flutter_assets/    default asset bundle

## Overrides

`FLUTTER_SWIFT_ENGINE_OUT` points at a different engine build.